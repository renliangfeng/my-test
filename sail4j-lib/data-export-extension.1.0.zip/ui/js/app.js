/**
 * Create the module.
 */
var myApp = angular.module('DataExportExt', ['ui.bootstrap', 'sailpoint.i18n',
    'sailpoint.comment', 'sailpoint.email', 'sailpoint.esig',
    'sailpoint.identity.account', 'sailpoint.modal',
    'sailpoint.util', 'sailpoint.tree', 'sailpoint.ui.bootstrap.carousel',
    'sailpoint.dataview', 'sailpoint.config']);

myApp.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
}])

myApp.controller('DataExportExtController', function ($scope, $http, $q, navigationService) {
    console.log("Starting DataExportExtController");

    var config = {
        headers: {
            'X-XSRF-TOKEN': PluginHelper.getCsrfToken()
        }
    }, promises;

    
    $scope.exportTypes = [
        {
            type: 'IDENTITY_ATTRIBUTES',
            display: 'Identity Attributes'
        },
        {   
            type: 'ACCOUNT_ATTRIBUTES',
            display: 'Account Attributes'
        }
    ];

    $scope.exportType = '';

    $scope.compareExport1Id = -1;
    $scope.compareExport2Id = -1;

    $scope.showTable = false;

    $scope.validationError = '';
    $scope.validToSubmit = true;

    $scope.selectedAll = false;

    $scope.changeExportType = function () {
        $scope.clearUp();
        if ($scope.exportType == '') {
            return;
        }

        //Getting exports
        $http.get(PluginHelper.getPluginRestUrl('data-export-ext/exports/' + $scope.exportType), config).then(function (response) {
            console.log("Got a response for exports");
            //console.log(response);
            $scope.exports = response.data;
            $scope.showTable = true;
            $scope.compareExport1Id = -1;
            $scope.compareExport2Id = -1;

        });
    }

    $scope.downloadReport = function (exportId, exportType, createdTime) {
        var fileName = exportType + '-' + createdTime + '.csv';

        console.log("DownloadReport reportId: " + exportId);

        $http.get(PluginHelper.getPluginRestUrl('data-export-ext/download/' + exportId), config).then(function (response) {
            console.log("Got a response to download export file");
            var linkElement = document.createElement('a');
            try {
                var blob = new Blob([response.data], {
                    type: 'text/csv'
                });
                var url = window.URL.createObjectURL(blob);
                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", fileName);
                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            } catch (ex) {
                console.log(ex);
            }

        });

    };

    $scope.compareIdentityAttrExports = function () {
        console.log("Compare 2 identity attribute exports");

        if ($scope.compareExport1Id <= 0 || $scope.compareExport2Id <= 0) {
            $scope.validationError = 'Please select Primary Export file and Secondary Export file to compare';
            $scope.validToSubmit = false;
            return;
        }

        if ($scope.compareExport1Id == $scope.compareExport2Id) {
            $scope.validationError = 'Please select different Primary Export and Secondary Export files to compare';
            $scope.validToSubmit = false;
            return;
        }
        
        $http.get(PluginHelper.getPluginRestUrl('data-export-ext/identity-attr/export-compare/' + $scope.compareExport1Id + '/' + $scope.compareExport2Id), config).then(function (response) {
            console.log("Got a response to download report diff");
            var linkElement = document.createElement('a');
            try {
                var blob = new Blob([response.data], {
                    type: 'text/csv'
                });
                var url = window.URL.createObjectURL(blob);
                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", 'export-files-diff.csv');
                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            } catch (ex) {
                console.log(ex);
            }

        });
    };

    $scope.compareAccountAttrExports = function () {
        console.log("Compare 2 account attribute exports");

        if ($scope.compareExport1Id <= 0 || $scope.compareExport2Id <= 0) {
            $scope.validationError = 'Please select Primary Export file and Secondary Export file to compare';
            $scope.validToSubmit = false;
            return;
        }

        if ($scope.compareExport1Id == $scope.compareExport2Id) {
            $scope.validationError = 'Please select different Primary Export and Secondary Export files to compare';
            $scope.validToSubmit = false;
            return;
        }
        
        $http.get(PluginHelper.getPluginRestUrl('data-export-ext/account-attr/export-compare/' + $scope.compareExport1Id + '/' + $scope.compareExport2Id), config).then(function (response) {
            console.log("Got a response to download report diff");
            var linkElement = document.createElement('a');
            try {
                var blob = new Blob([response.data], {
                    type: 'text/csv'
                });
                var url = window.URL.createObjectURL(blob);
                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", 'export-files-diff.csv');
                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            } catch (ex) {
                console.log(ex);
            }

        });
    };

    $scope.selectAll = function () {
        console.log("selectAll");

        angular.forEach($scope.exports, function (exp, index) {
            exp.selected = !$scope.selectedAll;
        });

    };

    $scope.deleteExports = function () {
        console.log("deleteExports");

        var exportIDsToDelete = [];

        angular.forEach($scope.exports, function (exp, index) {
            if (exp.selected) {
               exportIDsToDelete.push(exp.exportId);
            }
        });

        if (exportIDsToDelete.length == 0) {
            $scope.validationError = 'Click checkbox on the left side of export records for deletion';
            $scope.validToSubmit = false;
            return;
        }

        $http.post(PluginHelper.getPluginRestUrl('data-export-ext/exports/delete'), exportIDsToDelete, config).then(function (response) {
            console.log("Delete exports");
            //console.log(response);

           $scope.clearUp();
           $scope.changeExportType();

        });
    };

    $scope.clearUp = function () {
        $scope.compareExport1Id = -1;
        $scope.compareExport2Id = -1;
        $scope.validationError = '';
        $scope.validToSubmit = true;
        $scope.selectedAll = false;
    };

});
